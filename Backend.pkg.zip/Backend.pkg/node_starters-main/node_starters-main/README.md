# node_starters
Get started with NodeJS

# prerequisites
<li>NodeJS</li>
<li>MongoDB</li>
<li>VSCode(or any other text editor)</li>

# How to start server on your local machine
 //Go to the project terminal and type the following commands
<ul>
 <li>npm i</li>
  <li>npm start</li>
 </ul>




